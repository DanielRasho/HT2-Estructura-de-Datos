/**
 * Provides shorthands to certain mathematics tasks.
 */
package App_utils.math;