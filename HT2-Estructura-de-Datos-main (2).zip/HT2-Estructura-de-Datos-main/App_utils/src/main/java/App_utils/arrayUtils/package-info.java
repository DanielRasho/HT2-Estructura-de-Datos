/**
 * Provides various classes to work with java Collections.
 */
package App_utils.arrayUtils;