# Hoja de Trabajo 2
Elaborado con java 17 y maven.

## Cómo ejecutarlo?
Ejecutar el jar ubicado en 'App_main/target/calculator-1.0SNAPSHOT.jar' con el siguiente comando:
```bash
java -jar calculator-1.0-SNAPSHOT.jar
```